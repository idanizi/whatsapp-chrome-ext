# whatsapp-chrome-ext
chrome extension for texting to WhatsApp without saving the number
